package com.example.panikbutton.data

data class Contact (
    var contactName: String,
    var contactPhone: Int,
    var contactEmail: String
)