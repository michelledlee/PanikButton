package com.example.panikbutton.data

data class User (
    var userName: String,
    var userPhone: Int,
    var userEmail: String
)