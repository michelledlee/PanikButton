package com.example.panikbutton.ui.profile

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.panikbutton.R
import com.example.panikbutton.data.Contact
import kotlinx.android.synthetic.main.fragment_profile.view.*

class ContactRecyclerAdapter(val context: Context,
                             val contacts: List<Contact>) :
    RecyclerView.Adapter<ContactRecyclerAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) :
            RecyclerView.ViewHolder(itemView) {
        val contactName = itemView.findViewById<TextView>(R.id.contact_title)
        val contactPhone = itemView.findViewById<TextView>(R.id.contact_phone)
        val contactEmail = itemView.findViewById<TextView>(R.id.contact_email)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.contact_item_recycler, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val contact = contacts[position]
        with(holder) {
            contactName?.let {
                it.text = contact.contactName
            }
            contactPhone?.let{
                it.text = contact.contactPhone.toString()
            }
            contactEmail?.let{
                it.text = contact.contactEmail
            }
        }
    }

    override fun getItemCount() = contacts.size
}