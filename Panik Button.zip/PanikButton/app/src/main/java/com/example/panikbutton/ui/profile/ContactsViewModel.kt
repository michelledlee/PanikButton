package com.example.panikbutton.ui.profile

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.panikbutton.data.ContactRepository

class ContactsViewModel(app: Application) : AndroidViewModel(app) {

    private val dataRepo = ContactRepository(app)
    val contactData = dataRepo.contactData

}
