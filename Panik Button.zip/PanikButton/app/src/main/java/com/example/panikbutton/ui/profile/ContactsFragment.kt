package com.example.panikbutton.ui.profile//package com.example.panikbutton.ui.todelete

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.panikbutton.R
import kotlinx.android.synthetic.main.fragment_contacts.*

@Suppress("DEPRECATION")
class ContactsFragment : Fragment() {

//    private lateinit var contactsViewModel: ContactsViewModel
//    private lateinit var recyclerView: RecyclerView
//    private lateinit var linearLayoutManager: LinearLayoutManager

//    private val contactsViewModel by viewModels<ContactsViewModel>()

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
//        linearLayoutManager = LinearLayoutManager(context)
//        contacts_recyclerView.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL ,false)
//        val view = inflater.inflate(R.layout.fragment_contacts, container, false)
//        recyclerView = view?.findViewById<RecyclerView?>(R.id.contacts_list)!!

//        contactsViewModel.contactData.observe(viewLifecycleOwner, Observer {
//            val contactNames = StringBuilder()
//            for (contact in it) {
//                contactNames.append(contact.contactName).append("\n")
//            }
//            contacts_title.text = contactNames
//            val adapter = ContactRecyclerAdapter(requireContext(), it)
//            recyclerView.adapter = adapter
//        })
//        return view
        return inflater.inflate(R.layout.fragment_contacts, container, false)
    }
}